drop table if exists Orders;
drop table if exists Inventory;
drop table if exists Customers;
drop table if exists ParkingSpots;

create table Orders(
order_num varchar(6),
order_date date,
customer char(4),
car varchar(10),
constraint pk_orders primary key (order_num)
);

create table Inventory(
car_id char(3),
car_year year,
make varchar(20),
model varchar(20),
class varchar(20),
color varchar(10),
price int,
car_availability varchar(20),
constraint pk_inventory primary key(car_id)
);

create table Customers(
cust_username varchar(25),
cust_fname varchar(20),
cust_lname varchar(20),
cust_pwd varchar(20),
constraint pk_customers primary key (cust_username)
);

create table ParkingSpots(
spot_no varchar(25),
spot_type varchar(20),
spot_price varchar(20),
spot_availability varchar(20),
constraint pk_parkingspots primary key (spot_no)
);