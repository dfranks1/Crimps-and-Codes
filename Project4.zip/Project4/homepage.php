<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<!DOCTYPE html>
<html>
<head>
  <title>Homepage</title>
  <link rel="stylesheet" type="text/css" href="carrental.css">
</head>
<body>
	<div>
		<h2 class="homepage">Dale's Travel Services</h2>
	</div>
	
	<div id="options">
		<a href="./index.php">Rent a car</a>
	</div><br>
		<div id="options">
		<a href="./prepay.php">Prepay for parking services</a>
	</div><br>
	<div id="options">
		<a href="./profile.php">View profile</a>
	</div>	
	<div id="options">
		<a href="./LoginOrCreate.php">Log out</a>
	</div>	


</body>
</html>