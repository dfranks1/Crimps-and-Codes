<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<?php
session_start();

//Initialize variables
$username = "";
$firstname = "";
$lastname = "";
$errors = array();
$carno = "";
$spotno = "";

//Connect to the database
$db = mysqli_connect('127.0.0.1', 'root', 'AurelionSol2197', 'carrental');

//Register new user
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
  $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
  $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
  

  //Form validation
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  //Check the database to make sure a user does not
  //already exist with the same username and/or email
  $user_check_query = "SELECT * FROM Customers WHERE cust_username='$username' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { //if username exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }
  }

  //Register user
  if (count($errors) == 0) {
	$password = $password_1;
  	$query = "INSERT INTO Customers (cust_username, cust_fname, cust_lname, cust_pwd)
  			  VALUES('$username', '$firstname', '$lastname', '$password')";
  	mysqli_query($db, $query);
  	$_SESSION['username'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: homepage.php');
  }
}

//User Login
if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  else if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  else {
  	$query = "SELECT * FROM Customers WHERE cust_username='$username' AND cust_pwd='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: homepage.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

//Rent a car
if (isset($_POST['rent_car'])) {
	$carno = mysqli_real_escape_string($db, $_POST['CarNo']);
	$query = "UPDATE Inventory SET car_availability='Unavailable' WHERE car_id='$carno'";
	$_SESSION['carno'] = $carno;
	header("location: rent.php?carno=".$carno);
}

//book a parking spot
if (isset($_POST['book_spot'])) {
	$spotno = mysqli_real_escape_string($db, $_POST['SpotNo']);
	$query = "UPDATE ParkingSpots SET spot_availability='Unavailable' WHERE ='$spotno'";
	$_SESSION['spotno'] = $spotno;
	header("location: rent.php?spotno=".$spotno);
}

//
if (isset($_POST['confirm'])) {
	$_SESSION['success'] = "You have rented the car";
	header('location: success.php');
}
?>
