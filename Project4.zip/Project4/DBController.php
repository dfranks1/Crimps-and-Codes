<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<?php
class DBController {
	private $host = "127.0.0.1";
	private $user = "root";
    private $password = "AurelionSol2197";
	private $database = "carrental";
	private $conn;
	
	//Establishes connection with database
    function __construct() {
        $this->conn = $this->connectDB();
	}
	function connectDB() {
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
	}
	//This runs a query
    function runQuery($query) {
		$result = mysqli_query($this->conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
    if(!empty($resultset))
    return $resultset;
	}
}
?>