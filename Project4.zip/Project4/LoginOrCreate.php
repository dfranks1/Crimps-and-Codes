<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<title>Project 4</title>
	<link rel="stylesheet" href="fifteen.css">
</head>

<body>
	<h1>Dale's Travel Services</h1>
		<div>
		<a href="./login.php">Login</a>
		</div><br>
		<div>
		<a href="./register.php">Create an account</a>
		</div>
</body>
</html>
	