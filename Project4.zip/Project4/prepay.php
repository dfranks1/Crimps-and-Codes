<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<?php
/*This uses the file DBController to establish a connection to the database and also
runs a query on the database using a function in DBController.php in order to retrieve
the value for classResult. classResult is used to form the list of options that users can click
to select the class of car they want to view*/
include 'DBController.php';
$db_handle = new DBController();
$classResult = $db_handle->runQuery("SELECT DISTINCT spot_type FROM ParkingSpots ORDER BY spot_no ASC");
?>

<?php include('server.php') ?>
<html>
<head>
<link href="carrental.css" type="text/css" rel="stylesheet" />
<title align="center">Search Parking Spot Info</title>
</head>
<body>
    
<h2 align="center">Search Parking Spot Information</h2>

    <p align="center"><a href="./homepage.php">HOME</a> </p>
    <form align="center" method="POST" name="search" action="prepay.php">
		<!--This div forms the original list of options for classes that users can click-->
        <div>
            <select name="spot_type[]" multiple="multiple">
                <option value="0" selected="selected">Select Parking Spot</option>
                <?php
                    if (! empty($classResult)) {
                        foreach ($classResult as $key => $value) {
                            echo '<option value="' . $classResult[$key]['spot_type'] . '">' . $classResult[$key]['spot_type'] . '</option>';
                        }
                    }
                ?>
            </select><br> <br>
            <button id="Filter">Search</button>
        </div>
            
        <?php
        if (! empty($_POST['spot_type'])) {
        ?>
		<!--This displays the correct columns from the inventory-->
        <table align="center" cellpadding="10" cellspacing="1">
            <tr>
                <th><strong>SpotNo</strong></th>
                <th><strong>Type</strong></th>
                <th><strong>Availability</strong></th>
            </tr>
		<!--This is the logic to determine what to select from Inventory.
		The SELECT part will always be from the Inventory, but we don't
		know the WHERE part (the condition) until the user selects and option-->
        <?php
            $query = "SELECT * from ParkingSpots";
            $i = 0;
            $selectedOptionCount = count($_POST['spot_type']);
            $selectedOption = "";
            while ($i < $selectedOptionCount) {
                $selectedOption = $selectedOption . "'" . $_POST['spot_type'][$i] . "'";
                if ($i < $selectedOptionCount - 1) {
                    $selectedOption = $selectedOption . ", ";
                }            
                $i ++;
            }
            $query = $query . " WHERE spot_type in (" . $selectedOption . ")";        
            $result = $db_handle->runQuery($query);
            }
            if (! empty($result)) {
                foreach ($result as $key => $value) {
        ?>
			<!--This displays the correct rows from the inventory depending on what user clicked-->
            <tr>
                <td><div><?php echo $result[$key]['spot_no']; ?></div></td>
                <td><div><?php echo $result[$key]['spot_type']; ?> </div></td>
                <td><div><?php echo $result[$key]['spot_availability']; ?> </div></td>        
            </tr>
        <?php
        }
        ?>             
    </table>
    <?php
    }
    ?>  
    </div>
	</form>
	
	<p align="center"><strong>See the spot you want? Enter its SpotNo below to book!</strong></p>
	<form method="post" action="prepay.php">
  	<div align="center">
		<label>SpotNo:</label>
		<input type="text" name="SpotNo" value="bookspot">
  	</div>
	<br>
  	<div align="center">
		<button type="submit" name="book_spot">Head to Payment Page</button>
  	</div>
	</form>
	
</body>
</html>