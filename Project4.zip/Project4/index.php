<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<?php
/*This uses the file DBController to establish a connection to the database and also
runs a query on the database using a function in DBController.php in order to retrieve
the value for classResult. classResult is used to form the list of options that users can click
to select the class of car they want to view*/
include 'DBController.php';
$db_handle = new DBController();
$classResult = $db_handle->runQuery("SELECT DISTINCT class FROM Inventory WHERE car_availability='Available' ORDER BY make ASC");
?>
<?php include('server.php') ?>
<html>
<head>
<link href="carrental.css" type="text/css" rel="stylesheet" />
<title align="center">Search Car Information</title>
</head>
<body>
    
<h2 align="center">Search Car Information</h2>

    <p align="center"><a href="./homepage.php">HOME</a> </p>
    <form align="center" method="POST" name="search" action="index.php">
		<!--This forms the original list of options for classes that users can click-->
        <div>
            <select name="class[]" multiple="multiple">
                <option value="0" selected="selected">Select Class</option>
                <?php
                    if (! empty($classResult)) {
                        foreach ($classResult as $key => $value) {
                            echo '<option value="' . $classResult[$key]['class'] . '">' . $classResult[$key]['class'] . '</option>';
                        }
                    }
                ?>
            </select><br> <br>
            <button id="Filter">Search</button>
        </div>
            
        <?php
        if (! empty($_POST['class'])) {
        ?>
		<!--This displays the correct columns from the inventory-->
        <table align="center" cellpadding="10" cellspacing="1">
            <tr>
                <th><strong>CarNo</strong></th>
                <th><strong>Color</strong></th>
                <th><strong>Make</strong></th>
                <th><strong>Model</strong></th>
                <th><strong>Year</strong></th>
                <th><strong>Class</strong></th>
                <th><strong>Price</strong></th>
                <th><strong>Available</strong></th>
            </tr>
		<!--This is the logic to determine what to select from Inventory.
		The SELECT part will always be from the Inventory, but we don't
		know the WHERE part (the condition) until the user selects and option-->
        <?php
            $query = "SELECT * from Inventory";
            $i = 0;
            $selectedOptionCount = count($_POST['class']);
            $selectedOption = "";
            while ($i < $selectedOptionCount) {
                $selectedOption = $selectedOption . "'" . $_POST['class'][$i] . "'";
                if ($i < $selectedOptionCount - 1) {
                    $selectedOption = $selectedOption . ", ";
                }            
                $i ++;
            }
            $query = $query . " WHERE class in (" . $selectedOption . ")";        
            $result = $db_handle->runQuery($query);
            }
            if (! empty($result)) {
                foreach ($result as $key => $value) {
        ?>
			<!--This displays the correct rows from the inventory depending on what user clicked-->
            <tr>
                <td><div><?php echo $result[$key]['car_id']; ?></div></td>
                <td><div><?php echo $result[$key]['color']; ?> </div></td>
                <td><div><?php echo $result[$key]['make']; ?> </div></td>
                <td><div><?php echo $result[$key]['model']; ?></div></td>
                <td><div><?php echo $result[$key]['car_year']; ?> </div></td>
                <td><div><?php echo $result[$key]['class']; ?> </div></td>
                <td><div><?php echo $result[$key]['price']; ?> </div></td>
                <td><div><?php echo $result[$key]['car_availability']; ?> </div></td>        
            </tr>
        <?php
        }
        ?>             
    </table>
    <?php
    }
    ?>  
    </div>
	</form>
	
	<p align="center"><strong>See the car you want? Enter its CarNo below to rent!</strong></p>
	<form method="post" action="index.php">
  	<div align="center">
		<label>CarNo:</label>
		<input type="text" name="CarNo" value="rentcar">
  	</div>
	<br>
  	<div align="center">
		<button type="submit" name="rent_car">Rent</button>
  	</div>
	</form>
	
</body>
</html>