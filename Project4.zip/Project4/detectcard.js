function getCreditCardType(accountNumber)
{
  var type = "";

  //MasterCard
  if (/^5[1-5]/.test(accountNumber))
  {
    type = "Mastercard";
  }

  //Visa
  else if (/^4/.test(accountNumber))
  {
    type = "Visa";
  }

  //American Express
  else if (/^3[47]/.test(accountNumber))
  {
    type = "American Express";
  }

  return type;
}