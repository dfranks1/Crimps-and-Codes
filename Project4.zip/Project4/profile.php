<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<!DOCTYPE html>
<html>
<head>
  <title>Profile</title>
  <link rel="stylesheet" type="text/css" href="carrental.css">
</head>
<body>
	<div>
		<h2 class="homepage">Personal Information</h2>
	</div>	
</body>
</html>