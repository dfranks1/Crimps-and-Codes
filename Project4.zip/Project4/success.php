<!--
Dale Franks
12/10/2019
Project 4
Travel Services
-->

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<title>Success</title>
	<link rel="stylesheet" href="fifteen.css">
</head>

<body>
	<h1>You rented a car or booked a parking spot!</h1>
		<div>
		<a href="./homepage.php">Back to home</a>
		</div><br>
</body>
</html>